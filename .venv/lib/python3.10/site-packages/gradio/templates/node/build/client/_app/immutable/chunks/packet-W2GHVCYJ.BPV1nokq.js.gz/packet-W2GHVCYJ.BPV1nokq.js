import { P, a } from "./mermaid-parser.core.DkjPMQxQ.js";
export {
  P as PacketModule,
  a as createPacketServices
};

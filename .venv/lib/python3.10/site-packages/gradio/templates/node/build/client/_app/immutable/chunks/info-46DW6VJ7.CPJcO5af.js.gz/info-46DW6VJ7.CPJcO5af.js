import { I, c } from "./mermaid-parser.core.DkjPMQxQ.js";
export {
  I as InfoModule,
  c as createInfoServices
};

import { A, e } from "./mermaid-parser.core.DkjPMQxQ.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};

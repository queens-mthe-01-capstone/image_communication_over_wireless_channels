import { G, f } from "./mermaid-parser.core.DkjPMQxQ.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
